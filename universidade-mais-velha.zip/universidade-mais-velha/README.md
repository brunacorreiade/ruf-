# Universidade fica mais velha

Análise dos ingressantes do ensino superior brasileiro com base nos microdados do Censo da Educação Superior de 2015, do Inep.

## Resultados gerais de 2015

- Total de ingressantes: 2.922.400
- Ingressantes com 30 anos ou mais: 784.622
- Participação dos ingressantes 30+: 26,85%
- Participação de 30+ na EaD: 51,50%
- Participação de 30+ no presencial: 19,16%
- Participação da rede privada entre os ingressantes 30+: 88,37%
- Participação de 30+ em Pedagogia: 46,94%
- Participação de 30+ em Serviço Social: 51,45%

## Fonte

Inep — Censo da Educação Superior de 2015.

Os microdados podem ser baixados na [página do Censo da Educação Superior do Inep](https://www.gov.br/inep/pt-br/acesso-a-informacao/dados-abertos/microdados/censo-da-educacao-superior).

O arquivo bruto não está incluído neste repositório. O notebook baixa o ZIP oficial e registra URL, tamanho e SHA-256 do arquivo analisado.

## Metodologia

A análise utiliza `MICRODADOS_CADASTRO_CURSOS_2015.CSV`, uma base agregada por curso. O total de ingressantes vem de `QT_ING`. Os ingressantes com 30 anos ou mais correspondem à soma de `QT_ING_30_34`, `QT_ING_35_39`, `QT_ING_40_49`, `QT_ING_50_59` e `QT_ING_60_MAIS`.

Pedagogia e Serviço Social foram identificados pelos códigos Cine `0113P01` e `0923S01`, respectivamente.

## Como reproduzir

1. Abra [`notebooks/analise_ingressantes_inep_2015.ipynb`](notebooks/analise_ingressantes_inep_2015.ipynb) no Google Colab.
2. Execute as células na ordem.
3. O notebook tentará baixar o ZIP oficial automaticamente. Se o servidor estiver indisponível, será possível enviar o arquivo manualmente.
4. Compare o SHA-256 registrado em `metadados_fonte_2015.csv` para confirmar que todos usaram o mesmo ZIP.

## Estrutura

- `notebooks/`: código da análise em células documentadas;
- `resultados/`: tabelas consolidadas em CSV;
- `requirements.txt`: dependências para execução fora do Colab.

## Limitações

A base pública de 2015 está agregada por curso. Os resultados se referem a ingressos ou vínculos de ingressantes, e não necessariamente a pessoas únicas.

Não é possível cruzar diretamente faixa etária e turno, pois essas informações aparecem como totais marginais separados na base.

Os resultados de 2015, isoladamente, não permitem concluir que a expansão da EaD provocou o aumento da participação dos ingressantes mais velhos. Essa hipótese deve ser testada por meio da comparação com 2024.
