# Resultados de 2015

Os CSVs desta pasta foram recuperados das saídas da execução original e tiveram os percentuais recalculados a partir das contagens.

Ao executar o notebook, estes arquivos são regenerados e também são criados `metadados_fonte_2015.csv`, `cursos_por_faixa_2015.csv` e `resultados_inep_2015.xlsx`.
